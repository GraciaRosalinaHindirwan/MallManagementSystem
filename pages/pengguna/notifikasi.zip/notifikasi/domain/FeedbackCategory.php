<?php

enum FeedbackCategory {}
